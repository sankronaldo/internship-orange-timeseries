<!--
This is an issue template. Please fill in the relevant details in the
sections below.
-->

##### Timeseries version
<!-- From menu _Options→Add-ons→Timeseries_ -->


##### Orange version
<!-- From menu _Help→About→Version_ or code `Orange.version.full_version` -->


##### Expected behavior



##### Actual behavior



##### Steps to reproduce the behavior



##### Additional info (worksheets, data, screenshots, ...)


